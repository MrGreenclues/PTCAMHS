<?php
session_start();

// Clear session variables
$_SESSION["user"] = "";
$_SESSION["usertype"] = "";

// Set the new timezone
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');
$_SESSION["date"] = $date;

// Import database and log function
include("connection.php");
include("logfunction.php");

// Initialize error message
$error = '<label for="promter" class="form-label"></label>';

// Check if there is a logout due to inactivity
if (isset($_GET['action']) && $_GET['action'] == 'timeout') {
    $timeout_message = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">You have been logged out due to inactivity. Please log in again.</label>';
} else {
    $timeout_message = '';  // No timeout message
}

if ($_POST) {
    $email = $_POST['useremail'];
    $password = $_POST['userpassword'];

    // Query the webuser table to determine the user type
    $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
    if ($result->num_rows == 1) {
        $utype = $result->fetch_assoc()['usertype'];
        
    // Check credentials based on user type
    if ($utype == 'p') {
        // Query the patient table for the user's email
        $checker = $database->query("SELECT * FROM patient WHERE pemail='$email'");
        if ($checker->num_rows == 1) {
            $patient = $checker->fetch_assoc(); // Fetch the patient record
            $hashedPassword = $patient['ppassword']; // Retrieve the hashed password

             // Verify the entered password against the hashed password
             if (password_verify($password, $hashedPassword)) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'p';

                // Log patient login
                addLog($email, 'patient', 'Logged into the system', $database);

                header('Location: patient/index.php');
                exit();
            }
        }
        } elseif ($utype == 'a') {
            $checker = $database->query("SELECT * FROM admin WHERE aemail='$email' AND apassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'a';

                // Log admin login
                addLog($email, 'admin', 'Logged into the system', $database);

                header('Location: admin/index.php');
                exit();
            }
        } elseif ($utype == 'd') {
            $checker = $database->query("SELECT * FROM doctor WHERE docemail='$email' AND docpassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'd';

                // Log doctor login
                addLog($email, 'doctor', 'Logged into the system', $database);

                header('Location: doctor/index.php');
                exit();
            }
        }

        // If credentials are invalid for the determined user type
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
    } else {
        // If no user exists with the entered email
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We cannot find an account with this email.</label>';
    }
} else {
    $error = '<label for="promter" class="form-label">&nbsp;</label>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td>
                    <p class="header-text">Welcome Back!</p>
                </td>
            </tr>
            <div class="form-body">
                <tr>
                    <td>
                        <p class="sub-text">Login with your details to continue</p>
                    </td>
                </tr>
                <tr>
                    <form action="" method="POST">
                    <td class="label-td">
                        <label for="useremail" class="form-label">Email: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <label for="userpassword" class="form-label">Password: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="password" name="userpassword" class="input-text" placeholder="Password" required>
                    </td>
                </tr>
                <tr>
                    <td><br>
                    <?php echo $error; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Login" class="login-btn btn-primary btn">
                    </td>
                </tr>
            </div>
            <tr>
                <td>
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Don't have an account&#63; </label>
                    <a href="signup.php" class="hover-link1 non-style-link">Sign Up</a>
                    <br><br><br>
                </td>
            </tr>
            </form>
        </table>
    </div>
    </center>

    <!-- Show timeout message if user was logged out due to inactivity -->
    <div>
        <?php echo $timeout_message; ?>
    </div>
</body>
</html>
