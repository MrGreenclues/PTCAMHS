<?php
// Masking an email
function anonymizeEmail($email) {
    $parts = explode('@', $email);
    $namePart = substr($parts[0], 0, 2) . str_repeat('*', strlen($parts[0]) - 2);
    return $namePart . '@' . $parts[1];
}

// Pseudonymizing a name
function pseudonymizeName($name) {
    return 'User_' . uniqid();
}

// Generalizing an NIC
function generalizeNIC($nic) {
    return substr($nic, 0, 4) . str_repeat('*', strlen($nic) - 4);
}

// Masking a phone number
function anonymizePhone($phone) {
    return substr($phone, 0, 3) . str_repeat('*', strlen($phone) - 6) . substr($phone, -3);
}

// Suppressing full address
function suppressAddress($address) {
    return "Address Suppressed";
}
?>