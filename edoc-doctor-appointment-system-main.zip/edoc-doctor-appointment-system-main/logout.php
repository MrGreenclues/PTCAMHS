<?php 
session_start();

// Include database connection and log function
include 'connection.php';
include 'log_function.php';

// Check if the user is logged in
if (isset($_SESSION['user_email']) && isset($_SESSION['user_type'])) {
    // Get the user email and type
    $userEmail = $_SESSION['user_email'];
    $userType = $_SESSION['user_type'];

    // Log the logout event
    addLog($userEmail, $userType, 'Logged out of the system', $database);
}

// Clear all session variables
$_SESSION = array();

// Clear session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 86400, '/');
}

// Destroy the session
session_destroy();

// Redirect the user to the login page
header('Location: login.php?action=logout');
exit();
?>
