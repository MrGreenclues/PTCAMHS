<?php

session_start();

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'd') {
        header("location: ../login.php");
        exit();
    }
} else {
    header("location: ../login.php");
    exit();
}

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if ($_GET) {
    // Import database and logging function
    include("../connection.php");
    include("../logfunction.php");

    $id = $_GET["id"];

    // Fetch session details for logging
    $result = $database->query("SELECT * FROM schedule WHERE scheduleid='$id'");
    if ($result && $result->num_rows == 1) {
        $session = $result->fetch_assoc();
        $title = $session['title'];
        $scheduledate = $session['scheduledate'];
        $scheduletime = $session['scheduletime'];

        // Log the action
        $doctorEmail = $_SESSION["user"]; // Fetch doctor email from session
        $action = "Deleted session titled '$title' scheduled on $scheduledate at $scheduletime.";
        logAction('doctor', $doctorEmail, $action, $database);
    }

    // Delete the session from the database
    $sql = $database->query("DELETE FROM schedule WHERE scheduleid='$id'");

    // Redirect back to the schedule page
    header("location: schedule.php?action=session-deleted");
    exit();
}
?>
