<?php

session_start();

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'd') {
        header("location: ../login.php");
        exit();
    }
} else {
    header("location: ../login.php");
    exit();
}

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if ($_GET) {
    // Import database and logging function
    include("../connection.php");
    include("../logfunction.php");

    $id = $_GET["id"];

    // Fetch appointment details for logging
    $result = $database->query("SELECT * FROM appointment WHERE appoid='$id'");
    if ($result && $result->num_rows == 1) {
        $appointment = $result->fetch_assoc();
        $patientId = $appointment['pid'];
        $scheduleId = $appointment['scheduleid'];
        $appointmentDate = $appointment['appodate'];

        // Fetch patient and schedule details
        $patientResult = $database->query("SELECT pname FROM patient WHERE pid='$patientId'");
        $patientName = ($patientResult && $patientResult->num_rows == 1) ? $patientResult->fetch_assoc()['pname'] : "Unknown";

        $scheduleResult = $database->query("SELECT title FROM schedule WHERE scheduleid='$scheduleId'");
        $scheduleTitle = ($scheduleResult && $scheduleResult->num_rows == 1) ? $scheduleResult->fetch_assoc()['title'] : "Unknown";

        // Log the action
        $doctorEmail = $_SESSION["user"]; // Fetch doctor email from session
        $action = "Deleted appointment for patient '$patientName' (ID: $patientId) in session '$scheduleTitle' on $appointmentDate.";
        logAction('doctor', $doctorEmail, $action, $database);
    }

    // Delete the appointment from the database
    $sql = $database->query("DELETE FROM appointment WHERE appoid='$id'");

    // Redirect back to the appointment page
    header("location: appointment.php?action=appointment-deleted");
    exit();
}
?>
