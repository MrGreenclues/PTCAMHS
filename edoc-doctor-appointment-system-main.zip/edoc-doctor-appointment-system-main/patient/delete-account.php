<?php

session_start();

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'p') {
        header("location: ../login.php");
        exit();
    } else {
        $useremail = $_SESSION["user"];
    }
} else {
    header("location: ../login.php");
    exit();
}

// Import database and logging function
include("../connection.php");
include("../logfunction.php");

// Fetch patient details
$sqlmain = "SELECT * FROM patient WHERE pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s", $useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["pid"];
$username = $userfetch["pname"];

// Handle account deletion
if ($_GET) {
    $id = $_GET["id"];

    // Fetch the account email before deletion for logging
    $sqlmain = "SELECT * FROM patient WHERE pid=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result001 = $stmt->get_result();
    $email = ($result001->fetch_assoc())["pemail"];

    // Log the account deletion action
    $action = "Deleted their account with email '$email'.";
    logAction('patient', $email, $action, $database);

    // Delete the account from `webuser` table
    $sqlmain = "DELETE FROM webuser WHERE email=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    // Delete the account from `patient` table
    $sqlmain = "DELETE FROM patient WHERE pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    // Redirect to logout page
    header("location: ../logout.php");
    exit();
}
?>
