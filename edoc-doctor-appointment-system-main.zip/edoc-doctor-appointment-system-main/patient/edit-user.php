<?php

// Import database and logging function
include("../connection.php");
include("../logfunction.php");

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if ($_POST) {
    $result = $database->query("SELECT * FROM webuser");
    $name = $_POST['name'];
    $nic = $_POST['nic'];
    $oldemail = $_POST["oldemail"];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $tele = $_POST['Tele'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $id = $_POST['id00'];

    if ($password == $cpassword) {
        $error = '3';

        $sqlmain = "SELECT patient.pid FROM patient INNER JOIN webuser ON patient.pemail = webuser.email WHERE webuser.email = ?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $id2 = $result->fetch_assoc()["pid"];
        } else {
            $id2 = $id;
        }

        if ($id2 != $id) {
            $error = '1';
        } else {
            // Update patient details
            $sql1 = "UPDATE patient SET pemail = '$email', pname = '$name', ppassword = '$password', pnic = '$nic', ptel = '$tele', paddress = '$address' WHERE pid = $id";
            $database->query($sql1);

            // Update webuser email
            $sql2 = "UPDATE webuser SET email = '$email' WHERE email = '$oldemail'";
            $database->query($sql2);

            // Log the profile update action
            $userType = 'patient'; // Assuming this script is for patient profile updates
            $action = "Updated profile details. Changes include: 
                        Name: '$name', 
                        NIC: '$nic', 
                        Email: '$email', 
                        Address: '$address', 
                        Telephone: '$tele'.";
            logAction($userType, $email, $action, $database);

            $error = '4';
        }
    } else {
        $error = '2';
    }
} else {
    $error = '3';
}

header("location: settings.php?action=edit&error=" . $error . "&id=" . $id);
?>
