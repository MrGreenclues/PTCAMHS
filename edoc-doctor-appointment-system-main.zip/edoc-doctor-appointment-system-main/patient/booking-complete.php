<?php

// Start session and check user type
session_start();

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'p') {
        header("location: ../login.php");
        exit();
    } else {
        $useremail = $_SESSION["user"];
    }
} else {
    header("location: ../login.php");
    exit();
}

// Import database and logging function
include("../connection.php");
include("../logfunction.php");

// Fetch patient details
$sqlmain = "SELECT * FROM patient WHERE pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s", $useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["pid"];
$username = $userfetch["pname"];

// Handle the booking
if ($_POST) {
    if (isset($_POST["booknow"])) {
        $apponum = $_POST["apponum"];
        $scheduleid = $_POST["scheduleid"];
        $date = $_POST["date"];

        // Fetch schedule details for logging
        $scheduleResult = $database->query("SELECT title, docid FROM schedule WHERE scheduleid='$scheduleid'");
        $schedule = $scheduleResult->fetch_assoc();
        $sessionTitle = $schedule['title'];
        $doctorId = $schedule['docid'];

        // Insert appointment into the database
        $sql2 = "INSERT INTO appointment(pid, apponum, scheduleid, appodate) VALUES ($userid, $apponum, $scheduleid, '$date')";
        $result = $database->query($sql2);

        // Log the booking action
        $action = "Booked appointment number $apponum for session '$sessionTitle' with doctor ID $doctorId on $date.";
        logAction('patient', $useremail, $action, $database);

        // Redirect to appointment page with a success message
        header("location: appointment.php?action=booking-added&id=" . $apponum . "&titleget=none");
        exit();
    }
}
?>
