<?php

session_start();

// Set the correct timezone for PHP
date_default_timezone_set('Asia/Manila'); // Adjust to your timezone

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'p') {
        header("location: ../login.php");
        exit();
    }
} else {
    header("location: ../login.php");
    exit();
}

if ($_GET) {
    // Import database and logging function
    include("../connection.php");
    include("../logfunction.php");

    $id = $_GET["id"];

    // Fetch appointment details for logging
    $result = $database->query("SELECT * FROM appointment WHERE appoid='$id'");
    if ($result && $result->num_rows == 1) {
        $appointment = $result->fetch_assoc();
        $scheduleId = $appointment['scheduleid'];
        $appointmentDate = $appointment['appodate'];

        // Fetch schedule details
        $scheduleResult = $database->query("SELECT title FROM schedule WHERE scheduleid='$scheduleId'");
        $scheduleTitle = ($scheduleResult && $scheduleResult->num_rows == 1) ? $scheduleResult->fetch_assoc()['title'] : "Unknown";

        // Log the action
        $patientEmail = $_SESSION["user"]; // Fetch patient email from session
        $action = "Deleted appointment in session '$scheduleTitle' scheduled on $appointmentDate.";
        logAction('patient', $patientEmail, $action, $database);
    }

    // Delete the appointment from the database
    $sql = $database->query("DELETE FROM appointment WHERE appoid='$id'");

    // Redirect back to the appointment page
    header("location: appointment.php?action=appointment-deleted");
    exit();
}
?>
