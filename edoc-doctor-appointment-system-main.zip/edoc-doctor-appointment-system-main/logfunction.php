<?php

// Function to add a log entry
function addLog($email, $type, $action, $database) {
    $sql = "INSERT INTO logs (user_email, user_type, action) VALUES (?, ?, ?)";
    if ($stmt = $database->prepare($sql)) {
        $stmt->bind_param("sss", $email, $type, $action);
        $stmt->execute();
        $stmt->close();
    } else {
        echo "Error preparing log query: " . $database->error;
    }
}

// Function to fetch logs based on user type
function fetchLogs($userType, $database) {
    $sql = "SELECT * FROM logs WHERE user_type = ? ORDER BY timestamp DESC LIMIT 50";
    if ($stmt = $database->prepare($sql)) {
        $stmt->bind_param("s", $userType);
        $stmt->execute();
        return $stmt->get_result();
    } else {
        echo "Error preparing log fetch query: " . $database->error;
    }
    $stmt->close(); // Close the statement
}

// Function to log actions with timestamp
function logAction($userType, $userEmail, $action, $database) {
    $timestamp = date('Y-m-d H:i:s'); // Current timestamp
    $sql = "INSERT INTO logs (user_email, user_type, action, timestamp) VALUES (?, ?, ?, ?)";
    if ($stmt = $database->prepare($sql)) {
        $stmt->bind_param("ssss", $userEmail, $userType, $action, $timestamp);
        $stmt->execute();
        $stmt->close();
    } else {
        echo "Error preparing log action query: " . $database->error;
    }
}

?>
