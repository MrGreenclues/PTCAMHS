-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 07:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@edoc.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `anonymized_patient_data`
--

CREATE TABLE `anonymized_patient_data` (
  `id` int(11) NOT NULL,
  `original_pid` int(11) NOT NULL,
  `anonymized_pemail` varchar(255) DEFAULT NULL,
  `anonymized_pname` varchar(255) DEFAULT NULL,
  `anonymized_paddress` varchar(255) DEFAULT NULL,
  `anonymized_pnic` varchar(15) DEFAULT NULL,
  `anonymized_ptel` varchar(15) DEFAULT NULL,
  `generalized_pdob` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `anonymized_patient_data`
--

INSERT INTO `anonymized_patient_data` (`id`, `original_pid`, `anonymized_pemail`, `anonymized_pname`, `anonymized_paddress`, `anonymized_pnic`, `anonymized_ptel`, `generalized_pdob`, `created_at`) VALUES
(92, 12, 'anon8040@example.com', '88c1a11e3a', 'Generalized Address', '123***', '098****', '2002', '2024-12-12 08:11:44'),
(93, 10, 'anon2017@example.com', '77f6ce2987', 'Generalized Address', '123***', '098****', '1999', '2024-12-12 08:11:44'),
(94, 13, 'anon5012@example.com', '5e925eb1d7', 'Generalized Address', '111***', '091****', '2024', '2024-12-12 08:11:44');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `pid`, `apponum`, `scheduleid`, `appodate`) VALUES
(1, 1, 1, 1, '2022-06-03'),
(6, 9, 2, 12, '2024-11-27'),
(5, 4, 1, 12, '2024-11-25'),
(10, 11, 1, 16, '2024-11-28'),
(11, 13, 1, 18, '2024-12-12'),
(12, 13, 2, 18, '2024-12-12'),
(14, 15, 1, 37, '2025-03-20'),
(15, 17, 1, 39, '2025-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `docnic` varchar(15) DEFAULT NULL,
  `doctel` varchar(15) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docid`, `docemail`, `docname`, `docpassword`, `docnic`, `doctel`, `specialties`, `feedback`) VALUES
(2, 'c@gmail.com', 'Christian Malibog', '123', '121212121212', '121212121212', 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_type` enum('admin','doctor','patient') DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `user_email`, `user_type`, `action`, `timestamp`) VALUES
(166, 'admin@edoc.com', 'admin', 'Deleted doctor with details: \r\n                   Name: \'Steward\', \r\n                   Email: \'stewardbenaning@gmail.com\', \r\n                   Specialties: 15.', '2024-11-28 13:01:20'),
(173, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 16:36:59'),
(167, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 13:05:05'),
(168, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 16:14:49'),
(169, 'exam@gmail.com', 'patient', 'Logged into the system', '2024-11-28 16:20:48'),
(170, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-11-28 16:22:11'),
(171, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 16:36:29'),
(172, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 16:36:33'),
(161, 'asd@gmail.com', 'patient', 'Deleted their account with email \'asd@gmail.com\'.', '2024-11-28 12:49:09'),
(160, 'asd@gmail.com', 'patient', 'Logged into the system', '2024-11-28 12:48:12'),
(159, 'ja@gmail.com', 'patient', 'Updated profile details. Changes include: \r\n                        Name: \'Jason Capinianes\', \r\n                        NIC: \'121212121212\', \r\n                        Email: \'ja@gmail.com\', \r\n                        Address: \'Surallah\', \r\n                ', '2024-11-28 12:46:09'),
(158, 'ja@gmail.com', 'patient', 'Updated profile details. Changes include: \r\n                        Name: \'Jason O. Capinianes\', \r\n                        NIC: \'121212121212\', \r\n                        Email: \'ja@gmail.com\', \r\n                        Address: \'Surallah\', \r\n             ', '2024-11-28 05:44:50'),
(157, 'ja@gmail.com', 'patient', 'Booked appointment number 1 for session \'Free Checkup\' with doctor ID 2 on 2024-11-28.', '2024-11-28 05:40:34'),
(156, 'ja@gmail.com', 'patient', 'Deleted appointment in session \'Free Checkup\' scheduled on 2024-11-28.', '2024-11-28 12:37:11'),
(155, 'ja@gmail.com', 'patient', 'Deleted appointment in session \'Free Checkup\' scheduled on 2024-11-28.', '2024-11-28 05:36:08'),
(154, 'c@gmail.com', 'doctor', 'Deleted session titled \'Free appointment\' scheduled on 2024-11-29 at 13:00:00.', '2024-11-28 12:32:08'),
(153, 'c@gmail.com', 'doctor', 'Deleted session titled \'test\' scheduled on 2024-11-29 at 00:00:00.', '2024-11-28 05:31:10'),
(152, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-11-28 12:29:17'),
(151, 'admin@edoc.com', 'admin', 'Added a session titled \'test\' for doctor ID 2 on 2024-11-29 at 00:00 with 2 patients.', '2024-11-28 12:28:59'),
(150, 'c@gmail.com', 'doctor', 'Deleted appointment for patient \'Jason Capinianes\' (ID: 11) in session \'Free Checkup\' on 2024-11-28.', '2024-11-28 05:26:23'),
(149, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-11-28 12:26:16'),
(148, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-11-28 12:24:59'),
(147, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-11-28 12:24:25'),
(146, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-11-28 12:24:13'),
(145, 'admin@edoc.com', 'admin', 'Added a session titled \'Free Checkup\' for doctor ID 2 on 2024-11-29 at 12:19 with 3 patients.', '2024-11-28 12:19:38'),
(144, 'admin@edoc.com', 'admin', 'Dropped session titled \'Checkup\' for doctor ID 2 on 2024-11-28 at 20:00:00.', '2024-11-28 12:18:48'),
(143, 'admin@edoc.com', 'admin', 'Dropped session titled \'test\' for doctor ID 2 on 2024-11-28 at 10:09:00.', '2024-11-28 05:17:37'),
(142, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-11-28 12:12:13'),
(174, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-10 19:24:09'),
(175, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-10 19:25:55'),
(176, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-10 19:38:36'),
(177, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-10 19:40:48'),
(178, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 13:24:45'),
(179, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:25:19'),
(180, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 13:45:59'),
(181, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:49:41'),
(182, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:49:56'),
(183, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:50:28'),
(184, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 13:50:45'),
(185, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:52:21'),
(186, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 13:52:42'),
(187, 'admin@edoc.com', 'admin', 'Added a session titled \'Check up\' for doctor ID 2 on 2024-12-13 at 15:53 with 1 patients.', '2024-12-12 13:53:59'),
(188, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:54:23'),
(189, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 13:56:19'),
(190, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 13:57:15'),
(191, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 13:57:30'),
(192, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 13:58:58'),
(193, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 14:02:14'),
(194, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 14:04:40'),
(195, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 14:05:24'),
(196, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 14:06:31'),
(197, 'khem@gmail.com', 'patient', 'Booked appointment number 1 for session \'Check up\' with doctor ID 2 on 2024-12-12.', '2024-12-12 14:09:04'),
(198, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 14:09:21'),
(199, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 14:09:38'),
(200, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 14:10:04'),
(201, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 14:10:40'),
(202, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:12:44'),
(203, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:13:21'),
(204, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 16:14:31'),
(205, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 16:21:51'),
(206, 'ja@gmail.com', 'patient', 'Logged into the system', '2024-12-12 16:22:03'),
(207, 'khem@gmail.com', 'patient', 'Logged into the system', '2024-12-12 16:46:42'),
(208, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 16:47:25'),
(209, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:48:58'),
(210, 'khem@gmail.com', 'patient', 'Logged into the system', '2024-12-12 16:51:18'),
(211, 'khem@gmail.com', 'patient', 'Booked appointment number 2 for session \'Check up\' with doctor ID 2 on 2024-12-12.', '2024-12-12 16:51:27'),
(212, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:51:41'),
(213, 'khem@gmail.com', 'patient', 'Logged into the system', '2024-12-12 16:52:24'),
(214, 'khem@gmail.com', 'patient', 'Updated profile details. Changes include: \r\n                        Name: \'khem castillanos\', \r\n                        NIC: \'1112222\', \r\n                        Email: \'khem@gmail.com\', \r\n                        Address: \'khem@gmail.com\', \r\n             ', '2024-12-12 16:53:10'),
(215, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:53:19'),
(216, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 16:53:41'),
(217, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:53:58'),
(218, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:54:42'),
(219, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 16:57:25'),
(220, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 16:58:59'),
(221, 'c@gmail.com', 'doctor', 'Logged into the system', '2024-12-12 16:59:41'),
(222, 'admin@edoc.com', 'admin', 'Logged into the system', '2024-12-12 17:02:01'),
(223, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 13:18:48'),
(224, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 13:18:56'),
(225, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 13:20:41'),
(226, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 13:58:14'),
(227, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 16:19:19'),
(228, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 16:28:34'),
(229, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-20 16:39:20'),
(230, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 16:42:49'),
(231, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 16:48:46'),
(232, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-20 16:50:23'),
(233, 'admin@edoc.com', 'admin', 'Added a session titled \'asd\' for doctor ID 0 on 2025-03-21 at 06:53 with 1 patients.', '2025-03-20 16:53:48'),
(234, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 16:54:19'),
(235, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-20 16:54:45'),
(236, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 17:14:24'),
(237, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 17:14:41'),
(238, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-20 17:15:08'),
(239, 'admin@edoc.com', 'admin', 'Added a session titled \'asd\' for doctor ID 2 on 2025-03-21 at 06:16 with 2 patients.', '2025-03-20 17:16:01'),
(240, 'ja@gmail.com', 'patient', 'Logged into the system', '2025-03-20 17:16:19'),
(241, 'ja@gmail.com', 'patient', 'Booked appointment number 1 for session \'asd\' with doctor ID 2 on 2025-03-20.', '2025-03-20 17:16:30'),
(242, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-20 17:17:10'),
(243, 'admin@edoc.com', 'admin', 'Added a session titled \'asdasd\' for doctor ID 2 on 2025-03-21 at 06:32 with 1 patients.', '2025-03-20 18:36:32'),
(244, 'admin@edoc.com', 'admin', 'Added a session titled \'asdasd\' for doctor ID  on 2025-03-21 at 06:32 with 1 patients.', '2025-03-20 18:40:38'),
(245, 'admin@edoc.com', 'admin', 'Added a session titled \'asdasd\' for doctor ID 2 on 2025-03-21 at 06:32 with 1 patients.', '2025-03-20 18:40:55'),
(246, 'admin@edoc.com', 'admin', 'Added a session titled \'asdasd\' for doctor ID 2 on 2025-03-21 at 06:32 with 1 patients.', '2025-03-20 18:43:24'),
(247, 'admin@edoc.com', 'admin', 'Added a session titled \'asdasd\' for doctor ID 2 on 2025-03-21 at 06:32 with 1 patients.', '2025-03-20 18:43:51'),
(248, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 19:54:24'),
(249, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 19:55:13'),
(250, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 19:55:27'),
(251, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID  on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 19:57:10'),
(252, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 19:57:27'),
(253, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 20:03:31'),
(254, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 20:04:11'),
(255, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 20:13:06'),
(256, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 20:13:33'),
(257, 'admin@edoc.com', 'admin', 'Added a session titled \'khem\' for doctor ID 2 on 2025-03-21 at 10:54 with 1 patients.', '2025-03-20 20:13:49'),
(258, 'admin@edoc.com', 'admin', 'Added a session titled \'Nonoy\' for doctor ID 2 on 2025-03-22 at 20:19 with 69 patients.', '2025-03-20 20:16:45'),
(259, 'admin@edoc.com', 'admin', 'Added a session titled \'Available Schedule\' for doctor ID 2 on 2025-03-21 at 11:23 with 4 patients.', '2025-03-20 20:20:31'),
(260, 'usericecube@gmail.com', 'patient', 'Booked appointment number 1 for session \'Available Schedule\' with doctor ID 2 on 2025-03-20.', '2025-03-20 22:55:25'),
(261, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-20 22:55:38'),
(262, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-21 19:13:58'),
(263, 'admin@edoc.com', 'admin', 'Added a session titled \'yow\' for doctor ID 2 on 2025-03-22 at 07:16 with 23 patients.', '2025-03-21 19:14:25'),
(264, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-21 20:46:14'),
(265, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-26 19:27:57'),
(266, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-28 22:33:53'),
(267, 'admin@edoc.com', 'admin', 'Added a session titled \'thursday\' for doctor ID 2 on 2025-03-29 at 01:37 with 4 patients.', '2025-03-28 22:36:39'),
(268, 'shyryljay03@gmail.com', 'patient', 'Booked appointment number 1 for session \'thursday\' with doctor ID 2 on 2025-03-28.', '2025-03-28 22:39:06'),
(269, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-28 22:39:20'),
(270, 'admin@edoc.com', 'admin', 'Added a session titled \'asdsad\' for doctor ID 2 on 2025-03-29 at 22:42 with 123 patients.', '2025-03-28 22:39:39'),
(271, 'shyryljay03@gmail.com', 'patient', 'Logged into the system', '2025-03-28 23:02:02'),
(272, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-03-31 13:46:48'),
(273, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-03-31 14:06:38'),
(274, 'admin@edoc.com', 'admin', 'Added a session titled \'Free Checkup Holiday\' for doctor ID 2 on 2025-04-01 at 08:07 with 3 patients.', '2025-03-31 14:07:12'),
(275, 'c@gmail.com', 'doctor', 'Logged into the system', '2025-05-05 10:08:49'),
(276, 'c@gmail.com', 'doctor', 'Deleted session titled \'Free Checkup\' scheduled on 2024-11-29 at 12:19:00.', '2025-05-05 10:10:26'),
(277, 'c@gmail.com', 'doctor', 'Deleted appointment for patient \'Jason Capinianes\' (ID: 12) in session \'asd\' on 2025-03-20.', '2025-05-05 18:02:08'),
(278, 'admin@edoc.com', 'admin', 'Logged into the system', '2025-05-06 09:27:53'),
(279, 'admin@edoc.com', 'admin', 'Added a session titled \'trstr\' for doctor ID 2 on 2025-05-07 at 10:28 with 9 patients.', '2025-05-06 09:28:19'),
(280, 'admin@edoc.com', 'admin', 'Added a session titled \'trstr\' for doctor ID 2 on 2025-05-07 at 10:28 with 9 patients.', '2025-05-06 09:28:27'),
(281, 'admin@edoc.com', 'admin', 'Added a session titled \'trstr\' for doctor ID 2 on 2025-05-07 at 10:28 with 9 patients.', '2025-05-06 09:28:33'),
(282, 'admin@edoc.com', 'admin', 'Added a session titled \'trstr\' for doctor ID 2 on 2025-05-07 at 10:28 with 9 patients.', '2025-05-06 09:28:40');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pnic` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pnic`, `pdob`, `ptel`) VALUES
(12, 'castillanokhim5@gmail.com', 'Jason Capinianes', '$2y$10$eT.bZ9h2XIgWztG3YnYQHefrwUS.QiVRQdo.vpNEY.ZxVtHbd86Ga', 'Surallah', '12342345412775', '2002-02-06', '0987654321'),
(10, 'exam@gmail.com', 'aaa aaaexample', '$2y$10$iPax2k4yh5bSND7Tc8ngo.qtrjnb7sMupZjErqapjxqwMimRAHxbm', 'ex', '123123213', '1999-02-23', '0987654321'),
(13, 'khem@gmail.com', 'khem castillanos', '123', 'khem@gmail.com', '1112222', '2024-12-13', '0912345678'),
(14, 'Patient1@gmail.com', 'khem castillano', '$2y$10$RYvI3eHPEmw3itXpB3LYIe2EJpBiXNuFH7wRcZwt0kwygPQegTOGC', 'PolMarGen', '111111', '2025-03-19', '0969696969'),
(15, 'usericecube@gmail.com', 'khim cast', '$2y$10$uUGaJBf5g2P/rO83PGQ7n.pnWmYaXWW0Wh.7GkDcAosL8eT1Xefz6', 'PolMarGen', '1112223355', '2025-03-21', '0967676715'),
(16, 'castillanokhim5@gmail.com', 'khim cast', '$2y$10$BHA8NTRdCZ8DW41qm.OFVeuHmL9GTo8otde3pRHcBGuxyfi1q36Ga', 'pol', '1112333', '2025-03-03', '0969696996'),
(17, 'shyryljay03@gmail.com', 'popoy castillano', '$2y$10$kDaodZz/1BVecWMYZGJQp.Hz5NzrUxP6sjYzMnCOwf7.BRsaKJZ3i', 'polmogeb', '123', '2025-03-29', '0976767672'),
(18, 'jeicapinianes@gmail.com', 'jason cap', '$2y$10$UT5v/yZHQVj80HKlaETH2eV327pAL1v4/KiJbSjbytuv/ByCkRgTa', 'asd', '123', '2025-03-06', '0928284874');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `docid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `timelimit` int(11) NOT NULL,
  `nop` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `docid`, `title`, `scheduledate`, `scheduletime`, `timelimit`, `nop`) VALUES
(42, '2', 'trstr', '2025-05-07', '10:28:00', 0, 9),
(8, '1', '12', '2024-10-31', '13:33:00', 0, 1),
(18, '2', 'Check up', '2024-12-13', '15:53:00', 0, 1),
(19, '0', 'asd', '2025-03-21', '06:53:00', 0, 1),
(20, '2', 'asd', '2025-03-21', '06:16:00', 0, 2),
(21, '2', 'asdasd', '2025-03-21', '06:32:00', 0, 1),
(22, '2', 'asdasd', '2025-03-21', '06:32:00', 0, 1),
(23, '2', 'asdasd', '2025-03-21', '06:32:00', 0, 1),
(24, '2', 'asdasd', '2025-03-21', '06:32:00', 0, 1),
(25, '2', 'asdasd', '2025-03-21', '06:32:00', 0, 1),
(26, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(27, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(28, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(29, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(30, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(31, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(32, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(33, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(34, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(35, '2', 'khem', '2025-03-21', '10:54:00', 0, 1),
(36, '2', 'Nonoy', '2025-03-22', '20:19:00', 0, 69),
(37, '2', 'Available Schedule', '2025-03-21', '11:23:00', 0, 4),
(38, '2', 'yow', '2025-03-22', '07:16:00', 0, 23),
(39, '2', 'thursday', '2025-03-29', '01:37:00', 0, 4),
(40, '2', 'asdsad', '2025-03-29', '22:42:00', 0, 123),
(41, '2', 'Free Checkup Holiday', '2025-04-01', '08:07:00', 0, 3),
(43, '2', 'trstr', '2025-05-07', '10:28:00', 0, 9),
(44, '2', 'trstr', '2025-05-07', '10:28:00', 0, 9),
(45, '2', 'trstr', '2025-05-07', '10:28:00', 0, 9);

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `sname`) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clinical biology'),
(8, 'Clinical chemistry'),
(9, 'Clinical neurophysiology'),
(10, 'Clinical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology');

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@edoc.com', 'a'),
('exam@gmail.com', 'p'),
('patient@edoc.com', 'p'),
('emhashenudara@gmail.com', 'p'),
('ja@gmail.com', 'p'),
('c@gmail.com', 'd'),
('khem@gmail.com', 'p'),
('Patient1@gmail.com', 'p'),
('usericecube@gmail.com', 'p'),
('castillanokhim5@gmail.com', 'p'),
('shyryljay03@gmail.com', 'p'),
('jeicapinianes@gmail.com', 'p');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `anonymized_patient_data`
--
ALTER TABLE `anonymized_patient_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `original_pid` (`original_pid`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docid`),
  ADD KEY `specialties` (`specialties`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `docid` (`docid`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anonymized_patient_data`
--
ALTER TABLE `anonymized_patient_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
