-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: edoc
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aemail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('admin@edoc.com','123');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `anonymized_patient_data`
--

DROP TABLE IF EXISTS `anonymized_patient_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anonymized_patient_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_pid` int(11) NOT NULL,
  `anonymized_pemail` varchar(255) DEFAULT NULL,
  `anonymized_pname` varchar(255) DEFAULT NULL,
  `anonymized_paddress` varchar(255) DEFAULT NULL,
  `anonymized_pnic` varchar(15) DEFAULT NULL,
  `anonymized_ptel` varchar(15) DEFAULT NULL,
  `generalized_pdob` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `original_pid` (`original_pid`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anonymized_patient_data`
--

LOCK TABLES `anonymized_patient_data` WRITE;
/*!40000 ALTER TABLE `anonymized_patient_data` DISABLE KEYS */;
INSERT INTO `anonymized_patient_data` VALUES (54,1,'anon3968@example.com','023a11caf0','Generalized Address','000***','012****','2000','2024-11-26 11:56:22'),(55,2,'anon3448@example.com','00643c3f48','Generalized Address','011***','070****','2022','2024-11-26 11:56:22'),(56,4,'anon3084@example.com','88c1a11e3a','Generalized Address','098***','098****','2003','2024-11-26 11:56:22'),(57,9,'anon7534@example.com','75ca0e2daa','Generalized Address','123***','098****','2002','2024-11-26 11:56:22'),(58,10,'anon2915@example.com','77f6ce2987','Generalized Address','123***','098****','1999','2024-11-26 11:56:22');
/*!40000 ALTER TABLE `anonymized_patient_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL,
  PRIMARY KEY (`appoid`),
  KEY `pid` (`pid`),
  KEY `scheduleid` (`scheduleid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,1,1,1,'2022-06-03'),(5,4,1,12,'2024-11-25');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL AUTO_INCREMENT,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `docnic` varchar(15) DEFAULT NULL,
  `doctel` varchar(15) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL,
  PRIMARY KEY (`docid`),
  KEY `specialties` (`specialties`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (2,'c@gmail.com','Christian Malibog','123','121212121212','121212121212',1);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) DEFAULT NULL,
  `user_type` enum('admin','doctor','patient') DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (11,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:10:18'),(10,'c@gmail.com','doctor','Logged into the system','2024-11-26 01:09:27'),(3,'admin@edoc.com','admin','Logged into the system','2024-11-26 00:10:39'),(4,'c@gmail.com','doctor','Logged into the system','2024-11-26 00:38:15'),(5,'admin@edoc.com','admin','Logged into the system','2024-11-26 00:39:18'),(6,'admin@edoc.com','admin','Added a session titled \'Wawew\' for doctor ID 2 on 2024-11-30 at 08:00 with 3 patients.','2024-11-25 18:02:45'),(7,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:03:24'),(8,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:03:44'),(9,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:04:15'),(12,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:15:45'),(13,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:18:20'),(14,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:19:45'),(15,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:19:51'),(16,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:20:17'),(17,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:21:28'),(18,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:22:10'),(19,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:25:27'),(20,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:25:34'),(21,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:27:06'),(22,'c@gmail.com','doctor','Logged into the system','2024-11-26 01:27:37'),(23,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:27:52'),(24,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:44:55'),(25,'c@gmail.com','doctor','Logged into the system','2024-11-26 01:46:00'),(26,'c@gmail.com','doctor','Logged into the system','2024-11-26 01:54:03'),(27,'ja@gmail.com','patient','Logged into the system','2024-11-26 01:55:44'),(28,'c@gmail.com','doctor','Logged into the system','2024-11-26 01:56:09'),(29,'admin@edoc.com','admin','Logged into the system','2024-11-26 01:57:13'),(30,'admin@edoc.com','admin','Logged into the system','2024-11-26 09:48:51'),(31,'ja@gmail.com','patient','Logged into the system','2024-11-26 09:52:45'),(32,'admin@edoc.com','admin','Logged into the system','2024-11-26 09:54:42'),(33,'admin@edoc.com','admin','Logged into the system','2024-11-26 17:12:11'),(34,'ja@gmail.com','patient','Logged into the system','2024-11-26 17:19:30'),(35,'admin@edoc.com','admin','Logged into the system','2024-11-26 17:35:00'),(36,'admin@edoc.com','admin','Logged into the system','2024-11-26 17:38:37'),(37,'admin@edoc.com','admin','Logged into the system','2024-11-26 17:46:16'),(38,'admin@edoc.com','admin','Logged into the system','2024-11-26 17:50:34'),(39,'c@gmail.com','doctor','Logged into the system','2024-11-26 17:53:12'),(40,'c@gmail.com','doctor','Logged into the system','2024-11-26 18:12:10'),(41,'c@gmail.com','doctor','Logged into the system','2024-11-26 18:18:54'),(42,'c@gmail.com','doctor','Logged into the system','2024-11-26 18:18:59'),(43,'c@gmail.com','doctor','Logged into the system','2024-11-26 18:35:08'),(44,'c@gmail.com','doctor','Logged into the system','2024-11-26 18:41:15'),(45,'admin@edoc.com','admin','Logged into the system','2024-11-26 18:53:27'),(46,'admin@edoc.com','admin','Logged into the system','2024-11-26 18:57:31'),(47,'c@gmail.com','doctor','Logged into the system','2024-11-26 19:00:17'),(48,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:00:29'),(49,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:28:22'),(50,'ja@gmail.com','patient','Logged into the system','2024-11-26 19:28:46'),(51,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:28:58'),(52,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:37:42'),(53,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:44:12'),(54,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:48:59'),(55,'admin@edoc.com','admin','Logged into the system','2024-11-26 19:56:12'),(56,'c@gmail.com','doctor','Logged into the system','2024-11-26 19:57:22'),(57,'c@gmail.com','doctor','Logged into the system','2024-11-26 20:01:54'),(58,'c@gmail.com','doctor','Logged into the system','2024-11-26 20:19:20'),(59,'admin@edoc.com','admin','Logged into the system','2024-11-26 20:20:32'),(60,'admin@edoc.com','admin','Logged into the system','2024-11-26 21:33:47'),(61,'admin@edoc.com','admin','Logged into the system','2024-11-26 21:44:25'),(62,'admin@edoc.com','admin','Logged into the system','2024-11-26 21:57:32'),(63,'admin@edoc.com','admin','Logged into the system','2024-11-26 22:03:10'),(64,'admin@edoc.com','admin','Logged into the system','2024-11-26 22:06:23');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pnic` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'patient@edoc.com','Test Patient','123','Sri Lanka','0000000000','2000-01-01','0120000000'),(2,'emhashenudara@gmail.com','Hashen Udara','123','Sri Lanka','0110000000','2022-06-03','0700000000'),(4,'ja@gmail.com','Jason Capinianes','123','Capurihan','09876523234','2003-02-14','0987654321'),(9,'asd@gmail.com','asd asd','$2y$10$Raa5zESdUaUiXTasfeI3YuA3fZ3wX9njYop3cMkK0652sfMfg/wVK','asd','123','2002-02-02','0987654321'),(10,'exam@gmail.com','aaa aaaexample','$2y$10$iPax2k4yh5bSND7Tc8ngo.qtrjnb7sMupZjErqapjxqwMimRAHxbm','ex','123123213','1999-02-23','0987654321');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL AUTO_INCREMENT,
  `docid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `nop` int(4) DEFAULT NULL,
  PRIMARY KEY (`scheduleid`),
  KEY `docid` (`docid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (12,'2','Wawew','2024-11-30','08:00:00',3),(8,'1','12','2024-10-31','13:33:00',1);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialties`
--

DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialties`
--

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
INSERT INTO `specialties` VALUES (1,'Accident and emergency medicine'),(2,'Allergology'),(3,'Anaesthetics'),(4,'Biological hematology'),(5,'Cardiology'),(6,'Child psychiatry'),(7,'Clinical biology'),(8,'Clinical chemistry'),(9,'Clinical neurophysiology'),(10,'Clinical radiology'),(11,'Dental, oral and maxillo-facial surgery'),(12,'Dermato-venerology'),(13,'Dermatology'),(14,'Endocrinology'),(15,'Gastro-enterologic surgery'),(16,'Gastroenterology'),(17,'General hematology'),(18,'General Practice'),(19,'General surgery'),(20,'Geriatrics'),(21,'Immunology'),(22,'Infectious diseases'),(23,'Internal medicine'),(24,'Laboratory medicine'),(25,'Maxillo-facial surgery'),(26,'Microbiology'),(27,'Nephrology'),(28,'Neuro-psychiatry'),(29,'Neurology'),(30,'Neurosurgery'),(31,'Nuclear medicine'),(32,'Obstetrics and gynecology'),(33,'Occupational medicine'),(34,'Ophthalmology'),(35,'Orthopaedics'),(36,'Otorhinolaryngology'),(37,'Paediatric surgery'),(38,'Paediatrics'),(39,'Pathology'),(40,'Pharmacology'),(41,'Physical medicine and rehabilitation'),(42,'Plastic surgery'),(43,'Podiatric Medicine'),(44,'Podiatric Surgery'),(45,'Psychiatry'),(46,'Public health and Preventive Medicine'),(47,'Radiology'),(48,'Radiotherapy'),(49,'Respiratory medicine'),(50,'Rheumatology'),(51,'Stomatology'),(52,'Thoracic surgery'),(53,'Tropical medicine'),(54,'Urology'),(55,'Vascular surgery'),(56,'Venereology');
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webuser`
--

DROP TABLE IF EXISTS `webuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webuser`
--

LOCK TABLES `webuser` WRITE;
/*!40000 ALTER TABLE `webuser` DISABLE KEYS */;
INSERT INTO `webuser` VALUES ('admin@edoc.com','a'),('exam@gmail.com','p'),('patient@edoc.com','p'),('emhashenudara@gmail.com','p'),('ja@gmail.com','p'),('c@gmail.com','d'),('asd@gmail.com','p');
/*!40000 ALTER TABLE `webuser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-26 22:08:26
